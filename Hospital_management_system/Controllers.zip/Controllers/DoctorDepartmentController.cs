using HMS_Backend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class DoctorDepartmentController : ControllerBase
{
    private readonly AppDbContext _context;

    public DoctorDepartmentController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetDoctorDepartments()
    {
        var doctorDepartments = await _context.DoctorDepartments
            .Include(dd => dd.Doctor)
            .Include(dd => dd.Department)
            .ToListAsync();

        return Ok(doctorDepartments);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetDoctorDepartment(int id)
    {
        var doctorDepartment = await _context.DoctorDepartments
            .Include(dd => dd.Doctor)
            .Include(dd => dd.Department)
            .FirstOrDefaultAsync(dd => dd.DoctorDepartmentId == id);

        if (doctorDepartment == null)
        {
            return NotFound();
        }

        return Ok(doctorDepartment);
    }

    [HttpPost]
    public async Task<IActionResult> Create(DoctorDepartment doctorDepartment)
    {
        _context.DoctorDepartments.Add(doctorDepartment);
        await _context.SaveChangesAsync();

        return Ok(doctorDepartment);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, DoctorDepartment doctorDepartment)
    {
        if (id != doctorDepartment.DoctorDepartmentId)
            return BadRequest();

        var oldDoctorDepartment = await _context.DoctorDepartments.FindAsync(id);

        if (oldDoctorDepartment == null)
            return NotFound();

        oldDoctorDepartment.DoctorID = doctorDepartment.DoctorID;
        oldDoctorDepartment.DepartmentID = doctorDepartment.DepartmentID;
        oldDoctorDepartment.UserID = doctorDepartment.UserID;
        oldDoctorDepartment.Modified = DateTime.Now;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var doctorDepartment = await _context.DoctorDepartments.FindAsync(id);

        if (doctorDepartment == null)
            return NotFound();

        _context.DoctorDepartments.Remove(doctorDepartment);
        await _context.SaveChangesAsync();

        return Ok();
    }
}
