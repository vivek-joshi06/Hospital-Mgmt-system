using HMS_Backend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class AppointmentController : ControllerBase
{
    private readonly AppDbContext _context;

    public AppointmentController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetAppointments()
    {
        var appointments = await _context.Appointments
            .Include(a => a.Doctor)
            .Include(a => a.Patient)
            .Include(a => a.Status)
            .ToListAsync();

        return Ok(appointments);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetAppointment(int id)
    {
        var appointment = await _context.Appointments
            .Include(a => a.Doctor)
            .Include(a => a.Patient)
            .Include(a => a.Status)
            .FirstOrDefaultAsync(a => a.AppointmentID == id);

        if (appointment == null)
        {
            return NotFound();
        }

        return Ok(appointment);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Appointment appointment)
    {
        _context.Appointments.Add(appointment);
        await _context.SaveChangesAsync();

        return Ok(appointment);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Appointment appointment)
    {
        if (id != appointment.AppointmentID)
            return BadRequest();

        var oldAppointment = await _context.Appointments.FindAsync(id);

        if (oldAppointment == null)
            return NotFound();

        oldAppointment.DoctorID = appointment.DoctorID;
        oldAppointment.PatientID = appointment.PatientID;
        oldAppointment.AppointmentStatus = appointment.AppointmentStatus;
        oldAppointment.AppointmentDate = appointment.AppointmentDate;
        oldAppointment.Description = appointment.Description;
        oldAppointment.SpecialRemarks = appointment.SpecialRemarks;
        oldAppointment.TotalConsultedAmount = appointment.TotalConsultedAmount;
        oldAppointment.Modified = DateTime.Now;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var appointment = await _context.Appointments.FindAsync(id);

        if (appointment == null)
            return NotFound();

        _context.Appointments.Remove(appointment);
        await _context.SaveChangesAsync();

        return Ok();
    }
}
