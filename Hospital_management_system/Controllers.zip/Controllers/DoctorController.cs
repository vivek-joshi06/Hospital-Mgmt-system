using HMS_Backend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class DoctorController : ControllerBase
{
    private readonly AppDbContext _context;

    public DoctorController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetDoctors()
    {
        var doctors = await _context.Doctors
            .Include(d => d.User)
            .ToListAsync();

        return Ok(doctors);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetDoctor(int id)
    {
        var doctor = await _context.Doctors
            .Include(d => d.User)
            .FirstOrDefaultAsync(d => d.DoctorID == id);

        if (doctor == null)
        {
            return NotFound();
        }

        return Ok(doctor);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Doctor doctor)
    {
        _context.Doctors.Add(doctor);
        await _context.SaveChangesAsync();

        return Ok(doctor);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Doctor doctor)
    {
        if (id != doctor.DoctorID)
            return BadRequest();

        var oldDoctor = await _context.Doctors.FindAsync(id);

        if (oldDoctor == null)
            return NotFound();

        oldDoctor.Name = doctor.Name;
        oldDoctor.Phone = doctor.Phone;
        oldDoctor.Email = doctor.Email;
        oldDoctor.Qualification = doctor.Qualification;
        oldDoctor.Specialization = doctor.Specialization;
        oldDoctor.IsActive = doctor.IsActive;
        oldDoctor.UserID = doctor.UserID;
        oldDoctor.Modified = DateTime.Now;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var doctor = await _context.Doctors.FindAsync(id);

        if (doctor == null)
            return NotFound();

        _context.Doctors.Remove(doctor);
        await _context.SaveChangesAsync();

        return Ok();
    }
}
