using HMS_Backend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class PatientController : ControllerBase
{
    private readonly AppDbContext _context;

    public PatientController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetPatients()
    {
        var patients = await _context.Patients
            .Include(p => p.User)
            .ToListAsync();

        return Ok(patients);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetPatient(int id)
    {
        var patient = await _context.Patients
            .Include(p => p.User)
            .FirstOrDefaultAsync(p => p.PatientID == id);

        if (patient == null)
        {
            return NotFound();
        }

        return Ok(patient);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Patient patient)
    {
        _context.Patients.Add(patient);
        await _context.SaveChangesAsync();

        return Ok(patient);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Patient patient)
    {
        if (id != patient.PatientID)
            return BadRequest();

        var oldPatient = await _context.Patients.FindAsync(id);

        if (oldPatient == null)
            return NotFound();

        oldPatient.Name = patient.Name;
        oldPatient.DateOfBirth = patient.DateOfBirth;
        oldPatient.Gender = patient.Gender;
        oldPatient.Email = patient.Email;
        oldPatient.Phone = patient.Phone;
        oldPatient.Address = patient.Address;
        oldPatient.City = patient.City;
        oldPatient.State = patient.State;
        oldPatient.IsActive = patient.IsActive;
        oldPatient.UserID = patient.UserID;
        oldPatient.Modified = DateTime.Now;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var patient = await _context.Patients.FindAsync(id);

        if (patient == null)
            return NotFound();

        _context.Patients.Remove(patient);
        await _context.SaveChangesAsync();

        return Ok();
    }
}
