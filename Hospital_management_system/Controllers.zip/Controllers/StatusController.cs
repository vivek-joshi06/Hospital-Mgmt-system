using HMS_Backend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class StatusController : ControllerBase
{
    private readonly AppDbContext _context;

    public StatusController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetStatuses()
    {
        var statuses = await _context.Statuses.ToListAsync();
        return Ok(statuses);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetStatus(int id)
    {
        var status = await _context.Statuses.FindAsync(id);

        if (status == null)
        {
            return NotFound();
        }

        return Ok(status);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Status status)
    {
        _context.Statuses.Add(status);
        await _context.SaveChangesAsync();

        return Ok(status);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Status status)
    {
        if (id != status.StatusID)
            return BadRequest();

        var oldStatus = await _context.Statuses.FindAsync(id);

        if (oldStatus == null)
            return NotFound();

        oldStatus.StatusName = status.StatusName;
        oldStatus.StatusCssClass = status.StatusCssClass;
        await _context.SaveChangesAsync();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var status = await _context.Statuses.FindAsync(id);

        if (status == null)
            return NotFound();

        _context.Statuses.Remove(status);
        await _context.SaveChangesAsync();

        return Ok();
    }
}
